# Simulador de Juros Compostos — Android + iOS

Projeto preparado a partir do simulador HTML/PWA existente.

## Stack
- Frontend: HTML/CSS/JavaScript já existente
- Empacotamento mobile: Capacitor
- Android: projeto nativo gerado pelo Capacitor
- iOS: projeto nativo gerado pelo Capacitor

## Pré-requisitos
- Node.js LTS
- Android Studio + Android SDK para Android
- macOS + Xcode para compilar/publicar iOS

## Gerar os projetos nativos
```bash
npm install
npx cap add android
npx cap add ios
npx cap sync
```

Depois:
```bash
npx cap open android
npx cap open ios
```

No Android Studio, gere APK/AAB.
No Xcode, configure assinatura/certificados e gere o app para TestFlight/App Store.

## ID do aplicativo
`com.juroscompostos.simulador`

## Estrutura
- `www/` — código do simulador
- `android/` — será criado por `npx cap add android`
- `ios/` — será criado por `npx cap add ios`
