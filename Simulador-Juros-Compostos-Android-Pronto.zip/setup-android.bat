@echo off
npm install
npx cap add android
npx cap sync
npx cap open android
