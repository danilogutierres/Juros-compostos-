# Android — Juros Compostos

Este projeto Android já contém o simulador em `app/src/main/assets/public/`.

## Abrir
Abra a pasta `android/` no Android Studio.

## Gerar APK de teste
No Android Studio:
1. Aguarde a sincronização do Gradle.
2. Menu **Build > Build APK(s)**.
3. O APK de debug ficará em:
   `app/build/outputs/apk/debug/app-debug.apk`

## Gerar APK release
Use **Build > Generate Signed App Bundle / APK** e crie/seleciona um keystore.
Para publicação na Google Play, prefira **Android App Bundle (AAB)**.

## Dados do app
Nome: Juros Compostos
Application ID: com.juroscompostos.simulador
Versão: 1.0 (versionCode 1)
Orientação: retrato
