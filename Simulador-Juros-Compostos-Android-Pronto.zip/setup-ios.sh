#!/bin/sh
npm install
npx cap add ios
npx cap sync
npx cap open ios
